from tkinter import * 
from GameRules import get2DList, display, next_generation

# importing tkinter and my functions to visualize the game of life.
root = Tk()
root.title('Game of Life')

grid = get2DList("input.txt")

x_size = len(grid)
y_size = len(grid[0])

x = 50
y = 50
X = x * x_size
Y = y * y_size

root.geometry(str(X)+'x'+str(X))

# create all  the main containers
center = Frame(root, bg='white', width=X, height=Y)

# layout all the main containers
root.grid_rowconfigure(int(X/x), weight=1)
root.grid_columnconfigure(int(Y/y), weight=1)
center.grid(row=1, sticky="nsew")
 
# create the center widgets
center.grid_rowconfigure(0, weight=1)
center.grid_columnconfigure(1, weight=1)

cell_ls = []
for i in range(x_size):
    for j in range(y_size):
        cell = Frame(center, bg='white', highlightbackground="black", highlightcolor="black", highlightthickness=1, width=x, height=y)
        cell.grid(row=i, column=j)
        cell_ls.append(cell)

# This part creates frames (cells or squares) according to given number.

def updateWindow():
    global grid
    global x_size
    global y_size
    for i in range(x_size):
        for j in range(y_size):
            if grid[i][j] == 1:
                cell_ls[(i * (y_size)) + j]['bg'] = "black"
            elif grid[i][j] == 0:
                cell_ls[(i * (y_size)) + j]['bg'] = "white"
    changeGrid()

# "Tkinter window" needs to be refreshed when we run the code once . 
# updateWindow function is for that . 
# 1 >> black    and    0 >> white  

def changeGrid():
    global grid
    grid = next_generation(grid)


# Finally  codes below provide us an animation of game.
updatePerSec = 0.5
runTotalSec = 10

updateWindow()
for i in range(int(updatePerSec*1000), int(runTotalSec*1000), int(updatePerSec*1000)):
    root.after(i, updateWindow)

root.mainloop()

# The "input.txt" or " runTotalSec " 
# can be altered to get different combinations ...
