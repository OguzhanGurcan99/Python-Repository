def get2DList(input_file):
    ls = []

    my_file = open(input_file, "r")
    lines = my_file.readlines()
    sizes = lines[0].split(",")

    num_row = int(sizes[0])
    num_col = int(sizes[1])

    for i in range(1, num_row+1):
        rows = lines[i].rstrip().split(" ")
        rows = [int(i) for i in rows]   
        ls.append(rows)

    return ls

# get2DList function is created to read user input and 
#  to convert it 2 dimensional list form to use efficiently.

def display(arr):
    x_len = len(arr)
    y_len = len(arr[0])

    for i in range(x_len):
        for j in range(y_len):
            print(arr[i][j], " ", end='')
        print()

# display function can show us how our array looks like in screen.

def next_generation(temp):
    arr = [row[:] for row in temp]  # copying array
    x_len = len(arr)
    y_len = len(arr[0])

    toBeChanged = []

    # By using these 4 for loop and array[][] index structure
    # I check every cell's neighbors and itself ( 0 or 1)
    # so that I decide if the cell will change in next step !!!
    for i in range(x_len):
        for j in range(y_len):
            
            alive_cells=0
            for x in range(-1,2):
                for y in range(-1,2):
                    check_1 = i+x
                    check_2 = j+y

                    if check_1 < 0 or check_2 < 0:
                        continue
                    
                    if check_1 > x_len-1 or check_2 > y_len-1:
                        continue
                    
                    if x == 0 and y == 0:
                        continue

                    # These check1 and check2 is created to prevent IndexError!!!
                    if arr[i+x][j+y] == 1:
                        alive_cells+=1

            #Counting alive neighbors of any cell.

            if arr[i][j] == 0: # dead_cell
                if alive_cells == 3:
                    toBeChanged.append((i,j))
            
            elif arr[i][j] == 1: # alive_cell
                if alive_cells <= 1 or alive_cells >= 4:
                    toBeChanged.append((i,j))

    #Every element in "toBeChanged list" will change  
    for e in toBeChanged:
        ex = e[0]
        ey = e[1]

        if arr[ex][ey] == 0:
            arr[ex][ey] = 1
        else:
            arr[ex][ey] = 0

    return arr
