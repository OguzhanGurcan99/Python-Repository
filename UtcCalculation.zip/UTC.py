import datetime as DT1
from datetime import datetime as dt

a = open("InsertedLeapSeconds.txt","r")
my_txt = a.readlines()

# THIS TXT FILE WILL BE USED IN FUNCTION BELOW  TO CALCULATE LEAP SECONDS !! 
#     <<<<<<<<<   IN  PART 3    <<<<<<<<<<<

def UTC_CONVERTER(ls):

# FIRST PART CHECKS IF THE INPUT FORM IS CORRECT >> [2020,8,24,45000] <<<< AN EXAMPLE CORRECT FORM
    if type(ls[0]) != int:
        print("Year must be an integer !")
        exit(1)
    if not 1 <= ls[1] <= 12:
        print("Month must be an integer between 1 and 12 !")
        exit(1)
    if not 1 <= ls[2] <= 31:
        print("Day must be an integer between 1 and 31 ! ")
        exit(1)
    if not 0 <= ls[3] < 86400:
        print("Seconds must be an integer between 0 and 86400 !")
        exit(1)
# CHECKING IS OVER HERE , AND IF THERE IS PROBLEM WITH INPUT,  CODE WILL BE STOPPED !!!
# exit(1) 

#  PART 2 >>>>  TAKEN INPUT NEEDS TO BE CONVERTED INTO A DATETIME OBJECT  
#              [ YEAR , MONTH, DAY, SECONDS ]  >>>>> (YEAR,MONTH,DAY, HOUR, MINUTE, SECOND) 

    total_seconds  = ls[3]
    hour = int(total_seconds / 3600)
    minute =  int( (total_seconds - ( hour*3600) ) / 60)
    second = total_seconds - ( (hour*3600) + (minute*60))

    my_input_date = dt(ls[0], ls[1], ls[2], hour, minute, second)
    
    UTC_DIFFERENCE = DT1.timedelta(hours= -3)
    UTC = my_input_date + UTC_DIFFERENCE
    
    print("UTC :" , UTC)
    print()
# NOW I HAVE A DATE WITH ALL NECESSARY INFORMATIONS

# PART 3 >>>  I AM GOING TO FIND "MODIFIED JULIAN DAY VALUE" FOR LEAP SECOND "INSERTION" DATES 
# AND THEN I COMPARE THESE VALUES   WITH >>>>>  MY INPUT DATE's  MODIFIED JULIAN DAY VALUE
# IN FINAL     N VALUE WILL BE KNOWN.  

    modified_julian_day = dt(1858,11,17)
    my_modified_julian_day = my_input_date - modified_julian_day
    #print(my_modified_julian_day)

    leap_se_insertion_dates = []
    for i in my_txt:
        date_data = i.rstrip().split(" ")
        day = int(date_data[0])
        month = date_data[1]
        year = int(date_data[2])
        if month =="Jan":
            leap_se_insertion_dates.append( dt(year,1,day) )
        elif month == "Jul":
            leap_se_insertion_dates.append( dt(year,7,day) )
    #print(leap_se_insertion_dates)

    MJD_LEAP_SECONDS = []
    for j in leap_se_insertion_dates:
        MJD_DAY_COUNT = ( j - modified_julian_day).days
        
        MJD_LEAP_SECONDS.append( MJD_DAY_COUNT )
    #print(MJD_LEAP_SECONDS)
# NOW I HAVE MJD  DAYS OF  LEAP SECONDS INSERTION DATES 

    N = 0
    for mjd_leap in MJD_LEAP_SECONDS:
        if mjd_leap <  my_modified_julian_day.days:
            N += 1
        else:
            break
    print("N VALUE >>", N)
    print()

#  A SIMPLE SOLUTION APPROACH TO GET THE " N " VALUE .
# N VALUE IS OBTAINED.  IN LAST PART EQUATIONS ARE WRITTEN 

    CONVERTED_RESULTS = []

    TAI_DIFFERENCE = DT1.timedelta(seconds = 10 + N)
    GPST_DIFFERENCE = DT1.timedelta(seconds = N - 9 )
    TT_DIFFERENCE = DT1.timedelta(seconds= 10 + N + 32.184)

    TAI = UTC + TAI_DIFFERENCE
    GPST = UTC + GPST_DIFFERENCE
    TT = UTC + TT_DIFFERENCE

    CONVERTED_RESULTS.append(TAI)
    CONVERTED_RESULTS.append(GPST)
    CONVERTED_RESULTS.append(TT)

    print("TAI:", TAI)
    print("GPST:", GPST)
    print("TT:", TT)
    print()
    #print(CONVERTED_RESULTS)

# CONVERTED RESULTS LIST CONTAINS (year,month,day,hour,minute,second) informations for every time scale.

# IN FINAL STEP I WILL CONVERT IT  TO THE (1 x 4) FORM SO THAT (year,month,day,second) WILL BE OBTAINED 

# JUST LIKE WANTED IN THE ASSIGNMENT PDF 
    
    Final_Output = []
    for final in CONVERTED_RESULTS:
        only_seconds = (final.hour)*3600  + (final.minute)*60 + final.second
        
        Final_Output.append( (final.year, final.month, final.day, only_seconds) )
    print(Final_Output)
    return Final_Output

# FUNCTION IS READY TO BE DISPLAYED BELOW 
 

UTC_CONVERTER([2021,12,7,60000])























'''

1 2 3
4 5 6
7 8 9

'''


def diagonal(arr, size):

    ct1=0
    ct2=0
    for i in size:
        ct1 += arr[i][i]
        ct2 += arr[i][size-i]

    rt = abs(ct1+ct2)



    return rt
