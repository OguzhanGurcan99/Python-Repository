tree = open("tree.txt","r")
items = tree.readlines()
son_info = {}

for i in items:
    family = i.rstrip()
    father = family.split(":")[0]
    kids= family.split(":")[1].split(",")
    son_info.update({father:kids})

def depth_first(n):
    flag =""
    dad = "A"
    path = []
    a = []
    deleted = []
    path.append(dad)
    a.append(dad)
    while True:
        if n == dad:
            break
        else:
            if son_info[dad] != [""]:
                if len(son_info[dad])==1:
                    if dad != "A":

                        dad = son_info[dad][0]
                        path.append(dad)
                        a.append(dad)
                        flag = "RED"
                    else:
                        dad = son_info[dad][0]
                        path.append(dad)
                        a.append(dad)
                        flag = "White"
                else:
                    dad = son_info[dad][0]
                    path.append(dad)
                    a.append(dad)

            else:
                a.remove(dad)
                dad = a[-1]
                son_info[dad].remove(son_info[dad][0])
                if flag =="RED":
                    a.remove(dad)

                    dad = a[-1]
                    son_info[dad].remove(son_info[dad][0])
                    flag ="White"
    print("DEPTH FIRST SEARCH ->", path)
    print(n," HAS FOUND")
    print("HUMAN SEARCH -> ", a)
    for i in path:
        if i not in a:
            deleted.append(i)
    #print("deleted: ",deleted)

#import sys
#depth_first(sys.argv[1])
print(depth_first("D"))
